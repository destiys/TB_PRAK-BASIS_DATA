<?php

include 'db.php';



// Mendapatkan nama table dari parameter GET

$table = $_GET['table'] ?? 'dosen'; // Default ke table dosen jika tidak ada parameter



// Menangani permintaan POST untuk menambahkan data

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    // Validasi input berdasarkan table

    switch ($table) {

        case 'dosen':

            $id_dosen = $_POST['id_dosen'];

            $nama_dosen = $_POST['nama_dosen'];

            $nip = $_POST['nip'];

            $jurusan = $_POST['jurusan'];



            $conn->query("INSERT INTO dosen (id_dosen, nama_dosen, nip, jurusan) VALUES ('$id_dosen', '$nama_dosen', '$nip', '$jurusan')");

            break;



        case 'mahasiswa':

            $id_mahasiswa = $_POST['id_mahasiswa'];

            $nim = $_POST['nim'];

            $nama_mahasiswa = $_POST['nama_mahasiswa'];

            $jurusan = $_POST['jurusan'];

            $kelas = $_POST['kelas'];

            $jenis_kelamin = $_POST['jenis_kelamin'];

            $tanggal_lahir = $_POST['tanggal_lahir'];

            $alamat = $_POST['alamat'];



            // Menghitung status kelulusan berdasarkan nilai

            $status_kelulusan = 'BELUM LULUS'; // Default status



            // Cek apakah mahasiswa sudah memiliki nilai

            $query_nilai = "SELECT AVG(nilai_angka) as rata_rata FROM nilai WHERE id_mahasiswa = '$id_mahasiswa'";

            $result_nilai = $conn->query($query_nilai);



            if ($result_nilai && $result_nilai->num_rows > 0) {

                $row_nilai = $result_nilai->fetch_assoc();

                $rata_rata = $row_nilai['rata_rata'];



                // Tentukan status kelulusan berdasarkan rata-rata nilai

                if ($rata_rata >= 70) {

                    $status_kelulusan = 'LULUS';

                }

            }



            // Simpan data mahasiswa

            $conn->query("INSERT INTO mahasiswa (id_mahasiswa, nim, nama_mahasiswa, jurusan, kelas, jenis_kelamin, tanggal_lahir, alamat, status_kelulusan) 

                         VALUES ('$id_mahasiswa', '$nim', '$nama_mahasiswa', '$jurusan', '$kelas', '$jenis_kelamin', '$tanggal_lahir', '$alamat', '$status_kelulusan')");

            break;



        case 'mata_kuliah':

            $id_mk = $_POST['id_mk'];

            $kode_mk = $_POST['kode_mk'];

            $nama_mk = $_POST['nama_mk'];

            $bobot_sks = $_POST['bobot_sks'];



            $conn->query("INSERT INTO mata_kuliah (id_mk, kode_mk, nama_mk, bobot_sks) 

                         VALUES ('$id_mk', '$kode_mk', '$nama_mk', '$bobot_sks')");

            break;



        case 'nilai':

    $id_nilai = $_POST['id_nilai'];

    $id_mahasiswa = $_POST['id_mahasiswa'];

    $id_mk = $_POST['id_mk'];

    $id_dosen = $_POST['id_dosen'];

    $nilai_angka = $_POST['nilai_angka'];

    $nilai_huruf = $_POST['nilai_huruf'];



    // Simpan data ke table nilai

    $conn->query("INSERT INTO nilai (id_nilai, id_mahasiswa, id_mk, id_dosen, nilai_angka, nilai_huruf) 

                 VALUES ('$id_nilai', '$id_mahasiswa', '$id_mk', '$id_dosen', '$nilai_angka', '$nilai_huruf')");



    // Hitung rata-rata nilai untuk mahasiswa

    $query_rata_rata = "SELECT AVG(nilai_angka) as rata_rata FROM nilai WHERE id_mahasiswa = '$id_mahasiswa'";

    $result_rata_rata = $conn->query($query_rata_rata);



    if ($result_rata_rata && $result_rata_rata->num_rows > 0) {

        $row_rata_rata = $result_rata_rata->fetch_assoc();

        $rata_rata = $row_rata_rata['rata_rata'];



        // Tentukan status kelulusan berdasarkan rata-rata nilai

        $status_kelulusan = ($rata_rata >= 70) ? 'LULUS' : 'BELUM LULUS';



        // Perbarui status kelulusan di table mahasiswa

        $conn->query("UPDATE mahasiswa SET status_kelulusan = '$status_kelulusan' WHERE id_mahasiswa = '$id_mahasiswa'");

    }

    break;



        default:

            echo "Tabel tidak valid.";

            break;

    }



    // Redirect Kembali ke halaman Utama

    header("Location: index.php?table=$table");

    exit();

}



// Menampilkan form berdasarkan table

switch ($table) {

    case 'dosen':

        $form_title = "Add Dosen";

        $form_fields = [

            ['label' => 'id_dosen', 'type' => 'number'],

            ['label' => 'nama_dosen', 'type' => 'text'],

            ['label' => 'nip', 'type' => 'text'],

            ['label' => 'jurusan', 'type' => 'text']

        ];

        break;



    case 'mahasiswa':

        $form_title = "Add Mahasiswa";

        $form_fields = [

            ['label' => 'id_mahasiswa', 'type' => 'number'],

            ['label' => 'nim', 'type' => 'text'],

            ['label' => 'nama_mahasiswa', 'type' => 'text'],

            ['label' => 'jurusan', 'type' => 'text'],

            ['label' => 'kelas', 'type' => 'text'],

            ['label' => 'jenis_kelamin', 'type' => 'select'], // Ubah menjadi select

            ['label' => 'tanggal_lahir', 'type' => 'date'],

            ['label' => 'alamat', 'type' => 'text'],

            ['label' => 'status_kelulusan', 'type' => 'auto'] // Tambahkan status kelulusan otomatis

        ];

        break;



    case 'mata_kuliah':

        $form_title = "Add Mata Kuliah";

        $form_fields = [

            ['label' => 'id_mk', 'type' => 'number'],

            ['label' => 'kode_mk', 'type' => 'text'],

            ['label' => 'nama_mk', 'type' => 'text'],

            ['label' => 'bobot_sks', 'type' => 'number']

        ];

        break;



    case 'nilai':

        $form_title = "Add Nilai";

        $form_fields = [

            ['label' => 'id_nilai', 'type' => 'number'],

            ['label' => 'id_mahasiswa', 'type' => 'number'],

            ['label' => 'id_mk', 'type' => 'number'],

            ['label' => 'id_dosen', 'type' => 'number'],

            ['label' => 'nilai_angka', 'type' => 'number'],

            ['label' => 'nilai_huruf', 'type' => 'text']

        ];

        break;



    default:

        echo "Tabel tidak valid.";

        exit();

}

?>



<!DOCTYPE html>

<html>

<head>

    <title><?= $form_title ?></title>

</head>

<body>

    <h2><?= $form_title ?></h2>

    <form method="post">

        <?php foreach ($form_fields as $field): ?>

            <?php if ($field['type'] === 'select'): ?>

                <!-- Kolom jenis_kelamin -->

                <?= $field['label'] ?>: 

                <select name="<?= $field['label'] ?>">

                    <option value="laki-laki">laki-laki</option>

                    <option value="perempuan">perempuan</option>

                </select><br><br>

            <?php elseif ($field['type'] === 'auto'): ?>

                <!-- Kolom status_kelulusan otomatis -->

                <!-- Tidak perlu ditampilkan di form karena dihitung otomatis -->

            <?php else: ?>

                <?= $field['label'] ?>: 

                <input type="<?= $field['type'] ?>" name="<?= $field['label'] ?>"><br><br>

            <?php endif; ?>

        <?php endforeach; ?>

        <button type="submit">Save</button>

    </form>

</body>

</html>