<?php
include 'db.php';

$table = $_GET['table'] ?? 'dosen';
$id = $_GET['id'] ?? null;

if (!$id || $_SERVER['REQUEST_METHOD'] != 'POST') {
    header("Location: index.php?table=$table");
    exit();
}

switch ($table) {
    case 'dosen':
        $nama_dosen = $_POST['nama_dosen'];
        $nip = $_POST['nip'];
        $jurusan = $_POST['jurusan'];
        $conn->query("UPDATE dosen SET nama_dosen='$nama_dosen', nip='$nip', jurusan='$jurusan' WHERE id_dosen='$id'");
        break;

    case 'mahasiswa':
        $nim = $_POST['nim'];
        $nama_mahasiswa = $_POST['nama_mahasiswa'];
        $jurusan = $_POST['jurusan'];
        $kelas = $_POST['kelas'];
        $jenis_kelamin = $_POST['jenis_kelamin'];
        $tanggal_lahir = $_POST['tanggal_lahir'];
        $alamat = $_POST['alamat'];

        $conn->query("UPDATE mahasiswa SET nim='$nim', nama_mahasiswa='$nama_mahasiswa', jurusan='$jurusan', kelas='$kelas', jenis_kelamin='$jenis_kelamin', tanggal_lahir='$tanggal_lahir', alamat='$alamat' WHERE id_mahasiswa='$id'");
        break;

    case 'mata_kuliah':
        $kode_mk = $_POST['kode_mk'];
        $nama_mk = $_POST['nama_mk'];
        $bobot_sks = $_POST['bobot_sks'];
        $conn->query("UPDATE mata_kuliah SET kode_mk='$kode_mk', nama_mk='$nama_mk', bobot_sks='$bobot_sks' WHERE id_mk='$id'");
        break;

    case 'nilai':
        $id_mahasiswa = $_POST['id_mahasiswa'];
        $id_mk = $_POST['id_mk'];
        $id_dosen = $_POST['id_dosen'];
        $nilai_angka = $_POST['nilai_angka'];
        $nilai_huruf = $_POST['nilai_huruf'];

        $conn->query("UPDATE nilai SET id_mahasiswa='$id_mahasiswa', id_mk='$id_mk', id_dosen='$id_dosen', nilai_angka='$nilai_angka', nilai_huruf='$nilai_huruf' WHERE id_nilai='$id'");

        // Update status kelulusan
        $result = $conn->query("SELECT AVG(nilai_angka) as rata_rata FROM nilai WHERE id_mahasiswa = '$id_mahasiswa'");
        if ($result && $row = $result->fetch_assoc()) {
            $status = ($row['rata_rata'] >= 70) ? 'LULUS' : 'BELUM LULUS';
            $conn->query("UPDATE mahasiswa SET status_kelulusan = '$status' WHERE id_mahasiswa = '$id_mahasiswa'");
        }
        break;
}

header("Location: index.php?table=$table");
exit();
?>
<!DOCTYPE html>
<html>
<head><title>Edit dosen</title></head>
<body>
    <h2>Edit dosen</h2>
    <form method="post">
    id: <input type="number" name="id_dosen"><br><br>
    nama_dosen: <input type="text" name="nama_dosen"><br><br>
    nip: <input type="text" name="nip"><br><br>
    jurusan: <input type="text" name="jurusan"><br><br>
    <button type="submit">Save</button>
</form>
</body>
</html>
