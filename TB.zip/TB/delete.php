<?php
include 'db.php';

$table = $_GET['table'] ?? 'dosen';
$id = $_GET['id'] ?? null;

if (!$id) {
    header("Location: index.php");
    exit();
}

switch ($table) {
    case 'dosen':
        $conn->query("DELETE FROM dosen WHERE id_dosen = '$id'");
        break;

    case 'mahasiswa':
        // Hapus semua nilai terkait
        $conn->query("DELETE FROM nilai WHERE id_mahasiswa = '$id'");
        $conn->query("DELETE FROM mahasiswa WHERE id_mahasiswa = '$id'");
        break;

    case 'mata_kuliah':
        // Hapus semua nilai terkait
        $conn->query("DELETE FROM nilai WHERE id_mk = '$id'");
        $conn->query("DELETE FROM mata_kuliah WHERE id_mk = '$id'");
        break;

    case 'nilai':
        // Ambil id_mahasiswa sebelum hapus
        $result = $conn->query("SELECT id_mahasiswa FROM nilai WHERE id_nilai = '$id'");
        if ($row = $result->fetch_assoc()) {
            $id_mahasiswa = $row['id_mahasiswa'];
        }

        $conn->query("DELETE FROM nilai WHERE id_nilai = '$id'");

        // Update status kelulusan
        if (!empty($id_mahasiswa)) {
            $result = $conn->query("SELECT AVG(nilai_angka) as rata_rata FROM nilai WHERE id_mahasiswa = '$id_mahasiswa'");
            if ($result && $row = $result->fetch_assoc()) {
                $status = ($row['rata_rata'] >= 70) ? 'LULUS' : 'BELUM LULUS';
                $conn->query("UPDATE mahasiswa SET status_kelulusan = '$status' WHERE id_mahasiswa = '$id_mahasiswa'");
            }
        }
        break;
}

header("Location: index.php?table=$table");
exit();
?>