<?php
// Include koneksi database
include 'db.php';

// Tentukan tabel yang akan ditampilkan berdasarkan parameter GET
$table = $_GET['table'] ?? 'mahasiswa'; // Default ke tabel mahasiswa jika tidak ada parameter

// Query data berdasarkan tabel yang dipilih
switch ($table) {
    case 'dosen':
        $query = "SELECT * FROM dosen";
        $title = "Data Dosen";
        break;
    case 'mahasiswa':
        $query = "SELECT * FROM mahasiswa";
        $title = "Data Mahasiswa";
        break;
    case 'mata_kuliah':
        $query = "SELECT * FROM mata_kuliah";
        $title = "Data Mata Kuliah";
        break;
    case 'nilai':
        $query = "SELECT * FROM nilai";
        $title = "Data Nilai";
        break;
    default:
        $query = "SELECT * FROM mahasiswa"; // Jika tabel tidak valid, tampilkan mahasiswa
        $title = "Data Mahasiswa";
        break;
}

// Eksekusi query
$result = $conn->query($query);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Sistem Akademik</title>
    <style>
        table { border-collapse: collapse; width: 80%; margin: 20px auto; }
        th, td { padding: 10px; border: 1px solid #ccc; text-align: center; }
        th { background-color: #f2f2f2; }
        h2 { text-align: center; }
        ul { list-style-type: none; padding: 0; margin: 0; display: flex; justify-content: center; gap: 20px; }
        li { cursor: pointer; font-weight: bold; }
        li.active { color: blue; }
    </style>
</head>
<body>

<!-- Menu Navigasi -->
<ul>
    <li class="<?= $table === 'dosen' ? 'active' : '' ?>"><a href="?table=dosen">Dosen</a></li>
    <li class="<?= $table === 'mahasiswa' ? 'active' : '' ?>"><a href="?table=mahasiswa">Mahasiswa</a></li>
    <li class="<?= $table === 'mata_kuliah' ? 'active' : '' ?>"><a href="?table=mata_kuliah">Mata Kuliah</a></li>
    <li class="<?= $table === 'nilai' ? 'active' : '' ?>"><a href="?table=nilai">Nilai</a></li>
</ul>

<h2><?= $title ?></h2>

<?php if ($result->num_rows > 0): ?>
    <table>
        <tr>
            <?php
            // Menampilkan header kolom berdasarkan struktur tabel
            $fields = $result->fetch_fields();
            foreach ($fields as $field) {
                echo "<th>" . $field->name . "</th>";
            }
            ?>
            <th>Aksi</th>
        </tr>
        <?php while ($row = $result->fetch_assoc()): ?>
            <tr>
                <?php foreach ($row as $value): ?>
                    <td><?= htmlspecialchars($value) ?></td>
                <?php endforeach; ?>
                <td>
                    <a href="edit.php?table=<?= $table ?>&id=<?= $row[$fields[0]->name] ?>">Edit</a> |
                    <a href="delete.php?table=<?= $table ?>&id=<?= $row[$fields[0]->name] ?>">Hapus</a>
                </td>
            </tr>
        <?php endwhile; ?>
    </table>
<?php else: ?>
    <p>Tidak ada data.</p>
<?php endif; ?>


<a href="create.php?table=<?= $table ?>">Add New</a><br><br>
</body>
</html>



